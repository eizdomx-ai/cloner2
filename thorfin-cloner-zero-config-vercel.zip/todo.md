# Thorfin Cloner - TODO

## Banco de Dados
- [x] Criar tabela `cloning_jobs` para rastrear histórico de clonagens
- [x] Criar tabela `cloning_events` para armazenar logs de eventos em tempo real

## Backend - API de Clonagem
- [x] Implementar procedimento tRPC `cloner.startCloning` com validação de campos
- [x] Implementar SSE endpoint para streaming de progresso em tempo real
- [x] Integrar Discord.js para interagir com API do Discord
- [x] Implementar lógica de clonagem de categorias
- [x] Implementar lógica de clonagem de canais de texto
- [x] Implementar lógica de clonagem de canais de voz
- [x] Implementar lógica de clonagem de cargos
- [x] Implementar tratamento de erros e validações
- [x] Implementar resumo final de clonagem

## Frontend - UI e Componentes
- [x] Criar layout elegante e refinado com tema sofisticado
- [x] Implementar campo de entrada para token do bot Discord
- [x] Implementar campo de entrada para ID do servidor alvo
- [x] Implementar campo de entrada para ID do servidor destino
- [x] Implementar validação de campos antes de iniciar clonagem
- [x] Implementar botão de iniciar clonagem com feedback visual
- [x] Implementar barra de progresso em tempo real
- [x] Implementar painel de logs de eventos com scroll automático
- [x] Implementar indicador de status final (sucesso/erro)
- [x] Implementar resumo de clonagem (quantidade de itens clonados)
- [x] Implementar tratamento de estados de carregamento

## Testes
- [x] Escrever testes unitários para validação de campos
- [x] Escrever testes para procedimentos tRPC
- [x] Testar fluxo completo de clonagem

## Refinamentos Visuais
- [x] Ajustar tipografia e espaçamentos
- [x] Validar contraste de cores e acessibilidade
- [x] Testar responsividade em diferentes tamanhos de tela
- [x] Adicionar micro-interações e animações suaves
