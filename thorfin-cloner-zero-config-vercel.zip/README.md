# 🔥 Thorfin Cloner

**Clone servidores Discord com precisão e controle total. Acompanhe cada etapa em tempo real.**

Uma ferramenta web elegante e poderosa para clonar servidores Discord, com interface intuitiva em tema vermelho, branco e preto. Suporta clonagem de categorias, canais de texto, canais de voz e cargos com acompanhamento de progresso em tempo real.

## ✨ Características

- **🎯 Clonagem Completa**: Categorias, canais de texto, canais de voz e cargos
- **📊 Progresso em Tempo Real**: Acompanhe cada etapa da clonagem com barra de progresso
- **📝 Log de Eventos**: Visualize todos os eventos com cores e ícones intuitivos
- **✅ Validação Robusta**: Validação de campos obrigatórios e permissões do bot
- **🎨 Design Moderno**: Interface elegante com tema vermelho, branco e preto
- **📱 Responsivo**: Funciona perfeitamente em desktop, tablet e mobile
- **🔐 Seguro**: Token do bot usado apenas para a sessão atual
- **⚡ Rápido**: Construído com React 19, Tailwind CSS 4 e tRPC

## 🚀 Deploy Rápido no Vercel

### Opção 1: Usar o Botão Deploy

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https%3A%2F%2Fgithub.com%2FYOUR_USERNAME%2Fthorfin-cloner&env=DATABASE_URL,JWT_SECRET,VITE_APP_ID,OAUTH_SERVER_URL,VITE_OAUTH_PORTAL_URL,OWNER_OPEN_ID,OWNER_NAME,BUILT_IN_FORGE_API_URL,BUILT_IN_FORGE_API_KEY,VITE_FRONTEND_FORGE_API_URL,VITE_FRONTEND_FORGE_API_KEY,VITE_ANALYTICS_ENDPOINT,VITE_ANALYTICS_WEBSITE_ID,VITE_APP_TITLE,VITE_APP_LOGO)

### Opção 2: Deploy Manual

1. **Crie um repositório no GitHub**:
   ```bash
   git clone https://github.com/YOUR_USERNAME/thorfin-cloner.git
   cd thorfin-cloner
   git push -u origin main
   ```

2. **Conecte ao Vercel**:
   - Acesse [vercel.com](https://vercel.com)
   - Clique em "New Project"
   - Selecione seu repositório GitHub
   - Configure as variáveis de ambiente (veja abaixo)
   - Clique em "Deploy"

## 🔧 Variáveis de Ambiente

Você precisa configurar as seguintes variáveis de ambiente:

```env
# Banco de Dados
DATABASE_URL=mysql://user:password@host:port/database

# Autenticação
JWT_SECRET=seu_jwt_secret_aqui
VITE_APP_ID=seu_app_id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://login.manus.im

# Usuário
OWNER_OPEN_ID=seu_open_id
OWNER_NAME=seu_nome

# APIs
BUILT_IN_FORGE_API_URL=https://api.manus.im
BUILT_IN_FORGE_API_KEY=sua_api_key
VITE_FRONTEND_FORGE_API_URL=https://api.manus.im
VITE_FRONTEND_FORGE_API_KEY=sua_frontend_key

# Analytics (opcional)
VITE_ANALYTICS_ENDPOINT=seu_analytics_endpoint
VITE_ANALYTICS_WEBSITE_ID=seu_website_id

# Branding
VITE_APP_TITLE=Thorfin Cloner
VITE_APP_LOGO=seu_logo_url
```

## 💻 Desenvolvimento Local

### Pré-requisitos

- Node.js 18+
- pnpm (ou npm/yarn)
- MySQL/TiDB database

### Instalação

1. **Clone o repositório**:
   ```bash
   git clone https://github.com/YOUR_USERNAME/thorfin-cloner.git
   cd thorfin-cloner
   ```

2. **Instale as dependências**:
   ```bash
   pnpm install
   ```

3. **Configure as variáveis de ambiente**:
   ```bash
   cp .env.example .env
   # Edite o arquivo .env com suas configurações
   ```

4. **Execute as migrações do banco de dados**:
   ```bash
   pnpm drizzle-kit generate
   pnpm drizzle-kit migrate
   ```

5. **Inicie o servidor de desenvolvimento**:
   ```bash
   pnpm dev
   ```

6. **Acesse a aplicação**:
   Abra [http://localhost:3000](http://localhost:3000) no seu navegador

## 📖 Como Usar

1. **Obtenha o Token do Bot Discord**:
   - Acesse [Discord Developer Portal](https://discord.com/developers/applications)
   - Crie uma nova aplicação
   - Vá para a aba "Bot" e copie o token

2. **Encontre os IDs dos Servidores**:
   - Ative o Modo de Desenvolvedor no Discord (Configurações → Avançado → Modo de Desenvolvedor)
   - Clique com botão direito no servidor e selecione "Copiar ID do Servidor"

3. **Configure a Clonagem**:
   - Cole o token do bot
   - Cole o ID do servidor alvo (a ser clonado)
   - Cole o ID do servidor destino (que receberá a clonagem)
   - Clique em "INICIAR CLONAGEM"

4. **Acompanhe o Progresso**:
   - Veja a barra de progresso em tempo real
   - Acompanhe os eventos no log
   - Receba o resumo ao final da clonagem

## 🧪 Testes

Execute os testes com:

```bash
pnpm test
```

Os testes cobrem:
- Validação de campos obrigatórios
- Validação de IDs diferentes
- Procedimentos tRPC
- Fluxo completo de clonagem

## 📁 Estrutura do Projeto

```
thorfin-cloner/
├── client/                 # Frontend React
│   ├── src/
│   │   ├── pages/         # Páginas
│   │   ├── components/    # Componentes reutilizáveis
│   │   ├── lib/           # Utilitários
│   │   └── index.css      # Estilos globais
│   └── public/            # Arquivos estáticos
├── server/                 # Backend Express + tRPC
│   ├── routers.ts         # Procedimentos tRPC
│   ├── db.ts              # Funções de banco de dados
│   ├── discordCloner.ts   # Lógica de clonagem Discord
│   └── _core/             # Infraestrutura
├── drizzle/               # Migrações e schema
├── shared/                # Código compartilhado
└── package.json           # Dependências

```

## 🔐 Segurança

- Tokens do bot são usados apenas durante a sessão
- Validação rigorosa de entrada
- Verificação de permissões do bot
- Tratamento robusto de erros
- Autenticação via OAuth

## 🛠️ Stack Tecnológico

### Frontend
- **React 19** - UI library
- **Tailwind CSS 4** - Styling
- **TypeScript** - Type safety
- **tRPC** - Type-safe API calls
- **Wouter** - Routing
- **Sonner** - Toast notifications

### Backend
- **Express 4** - Web framework
- **tRPC 11** - RPC framework
- **Drizzle ORM** - Database ORM
- **Discord.js 14** - Discord API
- **MySQL/TiDB** - Database

### DevTools
- **Vite** - Build tool
- **Vitest** - Test framework
- **TypeScript** - Type checking
- **Prettier** - Code formatting

## 📝 Licença

MIT - Sinta-se livre para usar este projeto em seus próprios projetos!

## 🤝 Contribuindo

Contribuições são bem-vindas! Por favor:

1. Faça um fork do projeto
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

## 📞 Suporte

Se encontrar problemas:

1. Verifique se o token do bot está correto
2. Certifique-se de que o bot tem permissões necessárias
3. Verifique os IDs dos servidores
4. Consulte o log de eventos para mais detalhes

## 🚀 Roadmap

- [ ] Histórico de clonagens
- [ ] Clonagem de mensagens
- [ ] Agendamento de clonagem
- [ ] Suporte a webhooks
- [ ] Backup automático
- [ ] Integração com Discord Commands

## 💡 Dicas

- O bot precisa ter permissões para gerenciar cargos e canais
- Coloque o bot acima dos cargos que deseja clonar
- Servidores muito grandes podem levar mais tempo
- Use um token de bot dedicado para segurança

---

**Feito com ❤️ por Thorfin Cloner Team**
