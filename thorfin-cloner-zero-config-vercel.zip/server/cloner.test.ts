import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return ctx;
}

describe("cloner.startCloning", () => {
  it("rejeita quando botToken está vazio", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.cloner.startCloning({
        botToken: "",
        sourceServerId: "123456",
        targetServerId: "789012",
      });
      expect.fail("Deveria ter lançado erro");
    } catch (error: any) {
      expect(error.message).toContain("Token do bot é obrigatório");
    }
  });

  it("rejeita quando sourceServerId está vazio", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.cloner.startCloning({
        botToken: "valid-token",
        sourceServerId: "",
        targetServerId: "789012",
      });
      expect.fail("Deveria ter lançado erro");
    } catch (error: any) {
      expect(error.message).toContain("ID do servidor alvo é obrigatório");
    }
  });

  it("rejeita quando targetServerId está vazio", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.cloner.startCloning({
        botToken: "valid-token",
        sourceServerId: "123456",
        targetServerId: "",
      });
      expect.fail("Deveria ter lançado erro");
    } catch (error: any) {
      expect(error.message).toContain("ID do servidor destino é obrigatório");
    }
  });

  it("rejeita quando sourceServerId e targetServerId são iguais", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.cloner.startCloning({
        botToken: "valid-token",
        sourceServerId: "123456",
        targetServerId: "123456",
      });
      expect.fail("Deveria ter lançado erro");
    } catch (error: any) {
      expect(error.message).toContain("Servidor alvo e destino devem ser diferentes");
    }
  });

  it("aceita entrada válida e retorna jobId", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    try {
      const result = await caller.cloner.startCloning({
        botToken: "valid-token",
        sourceServerId: "123456",
        targetServerId: "789012",
      });

      expect(result).toHaveProperty("jobId");
      expect(result).toHaveProperty("status");
      expect(result.status).toBe("started");
    } catch (error: any) {
      // Pode falhar por falta de banco de dados, mas a validação deve passar
      expect(error.message).not.toContain("Token do bot é obrigatório");
      expect(error.message).not.toContain("ID do servidor");
      expect(error.message).not.toContain("devem ser diferentes");
    }
  });
});

describe("cloner.getJob", () => {
  it("rejeita quando jobId não é fornecido", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.cloner.getJob({ jobId: 0 });
      expect.fail("Deveria ter lançado erro");
    } catch (error: any) {
      expect(error.message).toBeDefined();
    }
  });
});

describe("cloner.getEvents", () => {
  it("rejeita quando jobId não é fornecido", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.cloner.getEvents({ jobId: 0 });
      expect.fail("Deveria ter lançado erro");
    } catch (error: any) {
      expect(error.message).toBeDefined();
    }
  });
});
