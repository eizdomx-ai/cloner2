import { Client, GatewayIntentBits, ChannelType } from 'discord.js';
import { addCloningEvent, updateCloningJob } from './db';

export interface CloningProgress {
  jobId: number;
  totalItems: number;
  completedItems: number;
  currentStep: string;
}

export interface CloningResult {
  success: boolean;
  message: string;
  summary: {
    categoriesCreated: number;
    textChannelsCreated: number;
    voiceChannelsCreated: number;
    rolesCreated: number;
    totalItemsCreated: number;
  };
}

export class DiscordCloner {
  private client: Client;
  private token: string;
  private onProgress: (progress: CloningProgress) => Promise<void>;

  constructor(token: string, onProgress: (progress: CloningProgress) => Promise<void>) {
    this.token = token;
    this.onProgress = onProgress;
    this.client = new Client({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
      ],
    });
  }

  async clone(
    jobId: number,
    sourceServerId: string,
    targetServerId: string
  ): Promise<CloningResult> {
    try {
      // Validar token antes de fazer login
      if (!this.token || this.token.length < 10) {
        throw new Error('Token do bot inválido');
      }

      await this.logEvent(jobId, 'info', 'Conectando ao Discord...', 'Conexão');
      
      try {
        await this.client.login(this.token);
      } catch (error) {
        throw new Error('Falha ao autenticar com o token do bot. Verifique se o token está correto.');
      }

      await this.logEvent(jobId, 'info', 'Buscando servidores...', 'Servidores');
      
      let sourceGuild, targetGuild;
      try {
        sourceGuild = await this.client.guilds.fetch(sourceServerId);
        targetGuild = await this.client.guilds.fetch(targetServerId);
      } catch (error) {
        throw new Error('Servidor alvo ou destino não encontrado. Verifique os IDs dos servidores.');
      }

      if (!sourceGuild || !targetGuild) {
        throw new Error('Servidor alvo ou destino não encontrado');
      }

      // Validar permissões do bot
      const botMember = await targetGuild.members.fetchMe();
      if (!botMember.permissions.has('ManageRoles') || !botMember.permissions.has('ManageChannels')) {
        throw new Error('O bot não tem permissões suficientes. Ele precisa de permissões para gerenciar cargos e canais.');
      }

      const summary = {
        categoriesCreated: 0,
        textChannelsCreated: 0,
        voiceChannelsCreated: 0,
        rolesCreated: 0,
        totalItemsCreated: 0,
      };

      // Contar total de itens a serem clonados
      const roles = await sourceGuild.roles.fetch();
      const channels = await sourceGuild.channels.fetch();
      
      let totalItems = 0;
      for (const role of Array.from(roles.values())) {
        if (role.name !== '@everyone') totalItems++;
      }
      for (const channel of Array.from(channels.values())) {
        if (channel) totalItems++;
      }

      await updateCloningJob(jobId, { totalItems });

      // Clonar cargos primeiro
      await this.logEvent(jobId, 'info', `Iniciando clonagem de ${Array.from(roles.values()).filter(r => r.name !== '@everyone').length} cargos...`, 'Cargos');
      const roleMap = new Map<string, string>();

      for (const role of Array.from(roles.values())) {
        if (role.name === '@everyone') continue;

        try {
          const newRole = await targetGuild.roles.create({
            name: role.name,
            color: role.color,
            permissions: role.permissions,
            hoist: role.hoist,
            mentionable: role.mentionable,
          });

          roleMap.set(role.id, newRole.id);
          summary.rolesCreated++;
          summary.totalItemsCreated++;

          await this.logEvent(
            jobId,
            'success',
            `Cargo "${role.name}" criado com sucesso`,
            role.name
          );
          await this.updateProgress(jobId, summary.totalItemsCreated, totalItems);
        } catch (error) {
          const errorMsg = error instanceof Error ? error.message : 'Erro desconhecido';
          await this.logEvent(
            jobId,
            'error',
            `Erro ao criar cargo "${role.name}": ${errorMsg}`,
            role.name
          );
        }
      }

      // Clonar categorias e canais
      await this.logEvent(jobId, 'info', `Iniciando clonagem de ${Array.from(channels.values()).filter(c => c).length} canais...`, 'Canais');
      const categoryMap = new Map<string, string>();

      // Primeiro, clonar categorias
      for (const channel of Array.from(channels.values())) {
        if (!channel) continue;
        if (channel.type === ChannelType.GuildCategory) {
          try {
            const newCategory = await targetGuild.channels.create({
              name: channel.name,
              type: ChannelType.GuildCategory,
              permissionOverwrites: await this.mapPermissions(
                channel.permissionOverwrites,
                roleMap
              ),
            });

            categoryMap.set(channel.id, newCategory.id);
            summary.categoriesCreated++;
            summary.totalItemsCreated++;

            await this.logEvent(
              jobId,
              'success',
              `Categoria "${channel.name}" criada com sucesso`,
              channel.name
            );
            await this.updateProgress(jobId, summary.totalItemsCreated, totalItems);
          } catch (error) {
            const errorMsg = error instanceof Error ? error.message : 'Erro desconhecido';
            await this.logEvent(
              jobId,
              'error',
              `Erro ao criar categoria "${channel.name}": ${errorMsg}`,
              channel.name
            );
          }
        }
      }

      // Depois, clonar canais de texto e voz
      for (const channel of Array.from(channels.values())) {
        if (!channel) continue;

        if (channel.type === ChannelType.GuildText) {
          try {
            const newChannel = await targetGuild.channels.create({
              name: channel.name,
              type: ChannelType.GuildText,
              parent: categoryMap.get(channel.parentId || ''),
              topic: (channel as any).topic,
              nsfw: (channel as any).nsfw,
              rateLimitPerUser: (channel as any).rateLimitPerUser,
              permissionOverwrites: await this.mapPermissions(
                channel.permissionOverwrites,
                roleMap
              ),
            });

            summary.textChannelsCreated++;
            summary.totalItemsCreated++;

            await this.logEvent(
              jobId,
              'success',
              `Canal de texto "#${channel.name}" criado com sucesso`,
              channel.name
            );
            await this.updateProgress(jobId, summary.totalItemsCreated, totalItems);
          } catch (error) {
            const errorMsg = error instanceof Error ? error.message : 'Erro desconhecido';
            await this.logEvent(
              jobId,
              'error',
              `Erro ao criar canal de texto "#${channel.name}": ${errorMsg}`,
              channel.name
            );
          }
        } else if (channel.type === ChannelType.GuildVoice) {
          try {
            const newChannel = await targetGuild.channels.create({
              name: channel.name,
              type: ChannelType.GuildVoice,
              parent: categoryMap.get(channel.parentId || ''),
              bitrate: (channel as any).bitrate,
              userLimit: (channel as any).userLimit,
              permissionOverwrites: await this.mapPermissions(
                channel.permissionOverwrites,
                roleMap
              ),
            });

            summary.voiceChannelsCreated++;
            summary.totalItemsCreated++;

            await this.logEvent(
              jobId,
              'success',
              `Canal de voz "${channel.name}" criado com sucesso`,
              channel.name
            );
            await this.updateProgress(jobId, summary.totalItemsCreated, totalItems);
          } catch (error) {
            const errorMsg = error instanceof Error ? error.message : 'Erro desconhecido';
            await this.logEvent(
              jobId,
              'error',
              `Erro ao criar canal de voz "${channel.name}": ${errorMsg}`,
              channel.name
            );
          }
        }
      }

      await this.logEvent(
        jobId,
        'success',
        `Clonagem concluída com sucesso! ${summary.totalItemsCreated} itens foram criados.`,
        'Conclusão'
      );

      return {
        success: true,
        message: 'Clonagem concluída com sucesso',
        summary,
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Erro desconhecido';
      await this.logEvent(jobId, 'error', `Erro durante clonagem: ${errorMessage}`, 'Erro');
      throw error;
    } finally {
      try {
        await this.client.destroy();
      } catch (e) {
        // Ignorar erros ao desconectar
      }
    }
  }

  private async mapPermissions(
    permissionOverwrites: any,
    roleMap: Map<string, string>
  ): Promise<any[]> {
    const newPermissions = [];

    if (permissionOverwrites) {
      try {
        for (const overwrite of Array.from(permissionOverwrites.values())) {
          const ow = overwrite as any;
          const newId = roleMap.get(ow.id) || ow.id;
          newPermissions.push({
            id: newId,
            allow: ow.allow,
            deny: ow.deny,
            type: ow.type,
          });
        }
      } catch (error) {
        // Se houver erro ao mapear permissões, continuar sem elas
      }
    }

    return newPermissions;
  }

  private async logEvent(
    jobId: number,
    status: 'info' | 'success' | 'warning' | 'error',
    message: string,
    itemName?: string
  ): Promise<void> {
    try {
      await addCloningEvent({
        jobId,
        eventType: status,
        message,
        itemName: itemName || '',
        status,
      });
    } catch (error) {
      console.error('Erro ao registrar evento:', error);
    }
  }

  private async updateProgress(jobId: number, completedItems: number, totalItems: number): Promise<void> {
    try {
      await updateCloningJob(jobId, { completedItems });
      await this.onProgress({
        jobId,
        totalItems,
        completedItems,
        currentStep: `Processados ${completedItems}/${totalItems} itens`,
      });
    } catch (error) {
      console.error('Erro ao atualizar progresso:', error);
    }
  }
}
