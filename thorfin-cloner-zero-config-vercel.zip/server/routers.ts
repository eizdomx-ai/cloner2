import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { createCloningJob, getCloningJob, getCloningEvents, updateCloningJob } from "./db";
import { DiscordCloner } from "./discordCloner";
import { TRPCError } from "@trpc/server";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  cloner: router({
    startCloning: protectedProcedure
      .input(
        z.object({
          botToken: z.string().min(1, "Token do bot é obrigatório"),
          sourceServerId: z.string().min(1, "ID do servidor alvo é obrigatório"),
          targetServerId: z.string().min(1, "ID do servidor destino é obrigatório"),
        })
      )
      .mutation(async ({ ctx, input }) => {
        try {
          // Validar que os IDs são diferentes
          if (input.sourceServerId === input.targetServerId) {
            throw new TRPCError({
              code: "BAD_REQUEST",
              message: "Servidor alvo e destino devem ser diferentes",
            });
          }

          // Criar job de clonagem
          const result = await createCloningJob({
            userId: ctx.user.id,
            sourceServerId: input.sourceServerId,
            targetServerId: input.targetServerId,
            status: "running",
          });

          const jobId = (result as any).insertId || 1;

          // Executar clonagem em background
          const cloner = new DiscordCloner(input.botToken, async (progress) => {
            // Callback para atualizar progresso
          });

          cloner
            .clone(jobId, input.sourceServerId, input.targetServerId)
            .then(async (result) => {
              await updateCloningJob(jobId, {
                status: "completed",
                summary: JSON.stringify(result.summary),
              });
            })
            .catch(async (error) => {
              await updateCloningJob(jobId, {
                status: "failed",
                errorMessage: error instanceof Error ? error.message : "Erro desconhecido",
              });
            });

          return { jobId, status: "started" };
        } catch (error) {
          if (error instanceof TRPCError) throw error;
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: error instanceof Error ? error.message : "Erro ao iniciar clonagem",
          });
        }
      }),

    getJob: protectedProcedure
      .input(z.object({ jobId: z.number() }))
      .query(async ({ input }) => {
        const job = await getCloningJob(input.jobId);
        if (!job) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Job não encontrado",
          });
        }
        return job;
      }),

    getEvents: protectedProcedure
      .input(z.object({ jobId: z.number() }))
      .query(async ({ input }) => {
        const events = await getCloningEvents(input.jobId);
        return events;
      }),
  }),
});

export type AppRouter = typeof appRouter;
