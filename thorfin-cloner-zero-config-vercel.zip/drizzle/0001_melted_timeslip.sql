CREATE TABLE `cloning_events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`jobId` int NOT NULL,
	`eventType` varchar(64) NOT NULL,
	`message` text NOT NULL,
	`itemName` varchar(255),
	`status` enum('info','success','warning','error') NOT NULL DEFAULT 'info',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `cloning_events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `cloning_jobs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`sourceServerId` varchar(64) NOT NULL,
	`targetServerId` varchar(64) NOT NULL,
	`status` enum('pending','running','completed','failed') NOT NULL DEFAULT 'pending',
	`totalItems` int NOT NULL DEFAULT 0,
	`completedItems` int NOT NULL DEFAULT 0,
	`errorMessage` text,
	`summary` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `cloning_jobs_id` PRIMARY KEY(`id`)
);
