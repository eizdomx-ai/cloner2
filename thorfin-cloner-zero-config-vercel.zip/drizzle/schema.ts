import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const cloningJobs = mysqlTable("cloning_jobs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  sourceServerId: varchar("sourceServerId", { length: 64 }).notNull(),
  targetServerId: varchar("targetServerId", { length: 64 }).notNull(),
  status: mysqlEnum("status", ["pending", "running", "completed", "failed"]).default("pending").notNull(),
  totalItems: int("totalItems").default(0).notNull(),
  completedItems: int("completedItems").default(0).notNull(),
  errorMessage: text("errorMessage"),
  summary: text("summary"), // JSON string with cloning summary
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CloningJob = typeof cloningJobs.$inferSelect;
export type InsertCloningJob = typeof cloningJobs.$inferInsert;

export const cloningEvents = mysqlTable("cloning_events", {
  id: int("id").autoincrement().primaryKey(),
  jobId: int("jobId").notNull(),
  eventType: varchar("eventType", { length: 64 }).notNull(), // e.g., "category_created", "channel_created", "role_created"
  message: text("message").notNull(),
  itemName: varchar("itemName", { length: 255 }),
  status: mysqlEnum("status", ["info", "success", "warning", "error"]).default("info").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CloningEvent = typeof cloningEvents.$inferSelect;
export type InsertCloningEvent = typeof cloningEvents.$inferInsert;