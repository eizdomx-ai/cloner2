# 📦 Guia de Instalação - Thorfin Cloner

## 🚀 Deploy no Vercel (Recomendado)

### Passo 1: Preparar o GitHub

1. Crie um novo repositório no GitHub chamado `thorfin-cloner`
2. Clone este projeto e faça push:

```bash
git clone https://github.com/seu-usuario/thorfin-cloner.git
cd thorfin-cloner
git push -u origin main
```

### Passo 2: Deploy no Vercel

1. Acesse [vercel.com](https://vercel.com)
2. Clique em "New Project"
3. Selecione seu repositório `thorfin-cloner`
4. Configure as variáveis de ambiente (veja abaixo)
5. Clique em "Deploy"

### Passo 3: Configurar Variáveis de Ambiente

No painel do Vercel, adicione as seguintes variáveis:

| Variável | Valor | Descrição |
|----------|-------|-----------|
| `DATABASE_URL` | `mysql://...` | Sua string de conexão MySQL/TiDB |
| `JWT_SECRET` | `seu_secret_aleatorio` | Mínimo 32 caracteres |
| `VITE_APP_ID` | `seu_app_id` | ID da aplicação Manus |
| `OWNER_OPEN_ID` | `seu_open_id` | Seu Open ID Manus |
| `OWNER_NAME` | `Seu Nome` | Seu nome |
| `BUILT_IN_FORGE_API_KEY` | `sua_api_key` | Chave da API Manus |
| `VITE_FRONTEND_FORGE_API_KEY` | `sua_frontend_key` | Chave frontend Manus |

As demais variáveis já têm valores padrão configurados.

## 💻 Desenvolvimento Local

### Pré-requisitos

- Node.js 18 ou superior
- pnpm (ou npm/yarn)
- MySQL 8.0+ ou TiDB

### Instalação Passo a Passo

1. **Clone o repositório**:
```bash
git clone https://github.com/seu-usuario/thorfin-cloner.git
cd thorfin-cloner
```

2. **Instale as dependências**:
```bash
pnpm install
```

3. **Configure o banco de dados**:

Crie um arquivo `.env` na raiz do projeto:

```bash
cp .env.example .env
```

Edite o arquivo `.env` com suas configurações:

```env
DATABASE_URL=mysql://user:password@localhost:3306/thorfin_cloner
JWT_SECRET=seu_jwt_secret_aleatorio_aqui_minimo_32_caracteres
VITE_APP_ID=seu_app_id
OWNER_OPEN_ID=seu_open_id
OWNER_NAME=Seu Nome
BUILT_IN_FORGE_API_KEY=sua_api_key
VITE_FRONTEND_FORGE_API_KEY=sua_frontend_key
```

4. **Execute as migrações do banco de dados**:

```bash
pnpm drizzle-kit generate
pnpm drizzle-kit migrate
```

5. **Inicie o servidor de desenvolvimento**:

```bash
pnpm dev
```

6. **Acesse a aplicação**:

Abra seu navegador em [http://localhost:3000](http://localhost:3000)

## 🔧 Configuração do Discord Bot

### Passo 1: Criar a Aplicação

1. Acesse [Discord Developer Portal](https://discord.com/developers/applications)
2. Clique em "New Application"
3. Dê um nome à sua aplicação
4. Vá para a aba "Bot"
5. Clique em "Add Bot"

### Passo 2: Configurar Permissões

1. Na aba "Bot", copie o token (você usará isso na interface)
2. Vá para "OAuth2" → "URL Generator"
3. Selecione os scopes:
   - `bot`
   - `applications.commands`

4. Selecione as permissões:
   - Manage Roles
   - Manage Channels
   - Create Instant Invite
   - Manage Guild

5. Copie a URL gerada e acesse em seu navegador para adicionar o bot aos seus servidores

### Passo 3: Usar o Token

1. Acesse a aplicação Thorfin Cloner
2. Cole o token do bot no campo "Token do Bot Discord"
3. Cole os IDs dos servidores
4. Clique em "INICIAR CLONAGEM"

## 📝 Variáveis de Ambiente Explicadas

### Obrigatórias

- **DATABASE_URL**: String de conexão do seu banco MySQL/TiDB
  - Exemplo: `mysql://user:password@localhost:3306/thorfin`

- **JWT_SECRET**: Chave para assinar tokens JWT
  - Gere com: `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`

- **VITE_APP_ID**: ID da aplicação Manus OAuth
  - Obtenha no painel Manus

- **OWNER_OPEN_ID**: Seu identificador único Manus
  - Obtenha no painel Manus

- **OWNER_NAME**: Seu nome de usuário

- **BUILT_IN_FORGE_API_KEY**: Chave da API Manus (servidor)
  - Obtenha no painel Manus

- **VITE_FRONTEND_FORGE_API_KEY**: Chave da API Manus (frontend)
  - Obtenha no painel Manus

### Opcionais

- **VITE_ANALYTICS_ENDPOINT**: URL do seu serviço de analytics
- **VITE_ANALYTICS_WEBSITE_ID**: ID do website no analytics

## 🧪 Testes

Execute os testes localmente:

```bash
pnpm test
```

## 📊 Monitoramento

Após o deploy, você pode:

1. Ver logs em tempo real no Vercel Dashboard
2. Monitorar performance e uptime
3. Gerenciar variáveis de ambiente
4. Visualizar analytics

## 🆘 Troubleshooting

### Erro: "Database connection failed"
- Verifique se a `DATABASE_URL` está correta
- Certifique-se de que o banco está acessível
- Teste a conexão com um cliente MySQL

### Erro: "Invalid token"
- Verifique se o `JWT_SECRET` tem pelo menos 32 caracteres
- Regenere um novo secret

### Erro: "Bot missing permissions"
- Verifique as permissões do bot no Discord
- Certifique-se de que o bot está acima dos cargos que deseja clonar

### Erro: "Server not found"
- Ative o Modo de Desenvolvedor no Discord
- Verifique se está copiando o ID correto do servidor

## 📚 Recursos Úteis

- [Documentação do Vercel](https://vercel.com/docs)
- [Discord Developer Portal](https://discord.com/developers/applications)
- [Documentação do Discord.js](https://discord.js.org/)
- [Tailwind CSS Documentation](https://tailwindcss.com/docs)

## 💬 Suporte

Se encontrar problemas:

1. Consulte o arquivo README.md
2. Verifique os logs do Vercel
3. Abra uma issue no GitHub
4. Contacte o suporte

---

**Pronto! Sua aplicação Thorfin Cloner deve estar rodando! 🎉**
