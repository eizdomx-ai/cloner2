import { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/_core/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, CheckCircle2, AlertCircle, Zap } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';

interface CloningEvent {
  id: number;
  jobId: number;
  eventType: string;
  message: string;
  itemName: string | null;
  status: 'info' | 'success' | 'warning' | 'error';
  createdAt: Date;
}

export default function Home() {
  const { user, loading: authLoading } = useAuth();
  const [botToken, setBotToken] = useState('');
  const [sourceServerId, setSourceServerId] = useState('');
  const [targetServerId, setTargetServerId] = useState('');
  const [isCloning, setIsCloning] = useState(false);
  const [jobId, setJobId] = useState<number | null>(null);
  const [progress, setProgress] = useState(0);
  const [events, setEvents] = useState<CloningEvent[]>([]);
  const [cloningStatus, setCloningStatus] = useState<'idle' | 'running' | 'completed' | 'failed'>('idle');
  const [summary, setSummary] = useState<any>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const startCloningMutation = trpc.cloner.startCloning.useMutation();
  const getJobQuery = trpc.cloner.getJob.useQuery(
    { jobId: jobId || 0 },
    { enabled: !!jobId, refetchInterval: 1000 }
  );
  const getEventsQuery = trpc.cloner.getEvents.useQuery(
    { jobId: jobId || 0 },
    { enabled: !!jobId, refetchInterval: 500 }
  );

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [events]);

  useEffect(() => {
    if (getEventsQuery.data) {
      setEvents(getEventsQuery.data);
    }
  }, [getEventsQuery.data]);

  useEffect(() => {
    if (getJobQuery.data) {
      const job = getJobQuery.data;
      const totalItems = job.totalItems || events.length || 1;
      const progressPercent = totalItems > 0 ? (job.completedItems / totalItems) * 100 : 0;
      setProgress(Math.min(progressPercent, 100));

      if (job.status === 'completed') {
        setCloningStatus('completed');
        setIsCloning(false);
        if (job.summary) {
          try {
            setSummary(JSON.parse(job.summary));
          } catch (e) {
            setSummary(null);
          }
        }
      } else if (job.status === 'failed') {
        setCloningStatus('failed');
        setIsCloning(false);
        toast.error(`Clonagem falhou: ${job.errorMessage}`);
      } else if (job.status === 'running') {
        setCloningStatus('running');
      }
    }
  }, [getJobQuery.data, events.length]);

  const handleStartCloning = async () => {
    if (!botToken.trim()) {
      toast.error('Por favor, insira o token do bot Discord');
      return;
    }
    if (!sourceServerId.trim()) {
      toast.error('Por favor, insira o ID do servidor alvo');
      return;
    }
    if (!targetServerId.trim()) {
      toast.error('Por favor, insira o ID do servidor destino');
      return;
    }
    if (sourceServerId === targetServerId) {
      toast.error('Os servidores alvo e destino devem ser diferentes');
      return;
    }

    try {
      setIsCloning(true);
      setCloningStatus('running');
      setProgress(0);
      setEvents([]);
      setSummary(null);

      const result = await startCloningMutation.mutateAsync({
        botToken,
        sourceServerId,
        targetServerId,
      });

      setJobId(result.jobId);
      toast.success('Clonagem iniciada com sucesso!');
    } catch (error) {
      setIsCloning(false);
      setCloningStatus('idle');
      toast.error(error instanceof Error ? error.message : 'Erro ao iniciar clonagem');
    }
  };

  const getEventIcon = (status: string) => {
    switch (status) {
      case 'success':
        return <CheckCircle2 className="w-4 h-4 text-green-600" />;
      case 'error':
        return <AlertCircle className="w-4 h-4 text-red-600" />;
      case 'warning':
        return <AlertCircle className="w-4 h-4 text-yellow-600" />;
      default:
        return <Zap className="w-4 h-4 text-red-600" />;
    }
  };

  const getEventColor = (status: string) => {
    switch (status) {
      case 'success':
        return 'bg-green-50 border-l-4 border-green-600 dark:bg-green-950 dark:border-green-500';
      case 'error':
        return 'bg-red-50 border-l-4 border-red-600 dark:bg-red-950 dark:border-red-500';
      case 'warning':
        return 'bg-yellow-50 border-l-4 border-yellow-600 dark:bg-yellow-950 dark:border-yellow-500';
      default:
        return 'bg-slate-50 border-l-4 border-red-600 dark:bg-slate-800 dark:border-red-500';
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black">
        <Loader2 className="w-8 h-8 animate-spin text-red-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: 'linear-gradient(45deg, #dc2626 25%, transparent 25%, transparent 75%, #dc2626 75%, #dc2626), linear-gradient(45deg, #dc2626 25%, transparent 25%, transparent 75%, #dc2626 75%, #dc2626)',
          backgroundSize: '40px 40px',
          backgroundPosition: '0 0, 20px 20px'
        }} />
      </div>

      <div className="relative container py-12 px-4">
        {/* Header */}
        <div className="mb-16 text-center">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-12 h-12 bg-red-600 rounded-lg flex items-center justify-center">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-5xl md:text-6xl font-black text-white">
              THORFIN
            </h1>
          </div>
          <h2 className="text-2xl md:text-3xl font-bold text-red-600 mb-3">CLONER</h2>
          <p className="text-lg text-slate-300 max-w-2xl mx-auto">
            Clone servidores Discord com precisão e controle total. Acompanhe cada etapa em tempo real.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Formulário */}
          <div className="lg:col-span-1">
            <Card className="p-8 border-2 border-red-600 bg-white dark:bg-slate-900 shadow-2xl">
              <h2 className="text-2xl font-black text-black dark:text-white mb-8 flex items-center gap-2">
                <div className="w-1 h-6 bg-red-600" />
                CONFIGURAÇÃO
              </h2>

              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-bold text-black dark:text-white mb-2 uppercase tracking-wide">
                    Token do Bot
                  </label>
                  <Input
                    type="password"
                    placeholder="Insira seu token"
                    value={botToken}
                    onChange={(e) => setBotToken(e.target.value)}
                    disabled={isCloning}
                    className="bg-slate-100 dark:bg-slate-800 border-2 border-slate-300 dark:border-slate-600 text-black dark:text-white placeholder-slate-500 focus:border-red-600 focus:ring-red-600"
                  />
                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-2">
                    Seu token será usado apenas para esta sessão
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-bold text-black dark:text-white mb-2 uppercase tracking-wide">
                    Servidor Alvo
                  </label>
                  <Input
                    type="text"
                    placeholder="ID do servidor a clonar"
                    value={sourceServerId}
                    onChange={(e) => setSourceServerId(e.target.value)}
                    disabled={isCloning}
                    className="bg-slate-100 dark:bg-slate-800 border-2 border-slate-300 dark:border-slate-600 text-black dark:text-white placeholder-slate-500 focus:border-red-600 focus:ring-red-600"
                  />
                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-2">
                    O servidor que será clonado
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-bold text-black dark:text-white mb-2 uppercase tracking-wide">
                    Servidor Destino
                  </label>
                  <Input
                    type="text"
                    placeholder="ID do servidor de destino"
                    value={targetServerId}
                    onChange={(e) => setTargetServerId(e.target.value)}
                    disabled={isCloning}
                    className="bg-slate-100 dark:bg-slate-800 border-2 border-slate-300 dark:border-slate-600 text-black dark:text-white placeholder-slate-500 focus:border-red-600 focus:ring-red-600"
                  />
                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-2">
                    O servidor que receberá a clonagem
                  </p>
                </div>

                <Button
                  onClick={handleStartCloning}
                  disabled={isCloning || startCloningMutation.isPending}
                  className="w-full mt-8 bg-red-600 hover:bg-red-700 text-white font-black py-3 h-auto uppercase tracking-widest transition-all duration-200 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed border-2 border-red-600"
                >
                  {isCloning ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      CLONANDO...
                    </>
                  ) : (
                    <>
                      <Zap className="w-4 h-4 mr-2" />
                      INICIAR CLONAGEM
                    </>
                  )}
                </Button>
              </div>
            </Card>
          </div>

          {/* Progresso e Logs */}
          <div className="lg:col-span-2 space-y-6">
            {/* Barra de Progresso */}
            {isCloning && (
              <Card className="p-6 border-2 border-red-600 bg-white dark:bg-slate-900 shadow-2xl">
                <h3 className="text-lg font-black text-black dark:text-white mb-4 flex items-center gap-2 uppercase">
                  <div className="w-1 h-5 bg-red-600" />
                  Progresso
                </h3>
                <div className="space-y-4">
                  <Progress value={progress} className="h-3 bg-slate-300 dark:bg-slate-700" />
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-bold text-black dark:text-white uppercase">
                      {Math.round(progress)}% CONCLUÍDO
                    </span>
                    <span className="text-sm text-red-600 font-bold">
                      {events.length} EVENTOS
                    </span>
                  </div>
                </div>
              </Card>
            )}

            {/* Status Final */}
            {cloningStatus === 'completed' && summary && (
              <Card className="p-6 border-2 border-green-600 bg-white dark:bg-slate-900 shadow-2xl">
                <div className="flex items-start gap-4">
                  <CheckCircle2 className="w-8 h-8 text-green-600 flex-shrink-0 mt-1" />
                  <div className="flex-1">
                    <h3 className="text-lg font-black text-black dark:text-white mb-4 uppercase">
                      ✓ Clonagem Concluída
                    </h3>
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded border-l-4 border-green-600">
                        <p className="text-slate-600 dark:text-slate-400 font-bold uppercase text-xs">Categorias</p>
                        <p className="text-3xl font-black text-green-600 mt-1">
                          {summary.categoriesCreated}
                        </p>
                      </div>
                      <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded border-l-4 border-green-600">
                        <p className="text-slate-600 dark:text-slate-400 font-bold uppercase text-xs">Texto</p>
                        <p className="text-3xl font-black text-green-600 mt-1">
                          {summary.textChannelsCreated}
                        </p>
                      </div>
                      <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded border-l-4 border-green-600">
                        <p className="text-slate-600 dark:text-slate-400 font-bold uppercase text-xs">Voz</p>
                        <p className="text-3xl font-black text-green-600 mt-1">
                          {summary.voiceChannelsCreated}
                        </p>
                      </div>
                      <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded border-l-4 border-green-600">
                        <p className="text-slate-600 dark:text-slate-400 font-bold uppercase text-xs">Cargos</p>
                        <p className="text-3xl font-black text-green-600 mt-1">
                          {summary.rolesCreated}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>
            )}

            {cloningStatus === 'failed' && (
              <Alert className="bg-red-50 dark:bg-red-950 border-2 border-red-600">
                <AlertCircle className="h-5 w-5 text-red-600 font-bold" />
                <AlertDescription className="text-red-800 dark:text-red-200 font-bold">
                  ✗ A clonagem falhou. Verifique os logs abaixo para mais detalhes.
                </AlertDescription>
              </Alert>
            )}

            {/* Logs de Eventos */}
            <Card className="p-6 border-2 border-red-600 bg-white dark:bg-slate-900 shadow-2xl">
              <h3 className="text-lg font-black text-black dark:text-white mb-4 flex items-center gap-2 uppercase">
                <div className="w-1 h-5 bg-red-600" />
                Log de Eventos
              </h3>
              <ScrollArea className="h-96 border-2 border-slate-300 dark:border-slate-700 rounded-lg p-4 bg-slate-50 dark:bg-slate-800">
                <div className="space-y-2">
                  {events.length === 0 ? (
                    <p className="text-sm text-slate-500 dark:text-slate-400 text-center py-8 font-bold">
                      {isCloning ? '⏳ AGUARDANDO EVENTOS...' : '○ NENHUM EVENTO REGISTRADO'}
                    </p>
                  ) : (
                    events.map((event, index) => (
                      <div
                        key={index}
                        className={`flex items-start gap-3 p-3 rounded font-mono text-sm ${getEventColor(event.status)}`}
                      >
                        <div className="flex-shrink-0 mt-0.5">
                          {getEventIcon(event.status)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-bold text-slate-900 dark:text-white break-words">
                            {event.message}
                          </p>
                          {event.itemName && (
                            <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                              → {event.itemName}
                            </p>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                  <div ref={scrollRef} />
                </div>
              </ScrollArea>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
